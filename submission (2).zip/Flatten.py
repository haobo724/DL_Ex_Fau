import numpy as np

class Flatten:
    def __init__(self):
        pass

    def forward(self, input_tensor):
        #the first dimention of input_tensor repersent batch numbers.
        #we create a empty matrix which takes batch number as row and element number as column to store the reshaped input_tensor
        self.input_shape = input_tensor.shape
        total = input_tensor.shape[1] * input_tensor.shape[2] * input_tensor.shape[3]
        output = np.ones([input_tensor.shape[0],total])
        for i in range (input_tensor.shape[0]):
            output[i]=input_tensor[i].flatten()
        return  output

    def backward(self, error_tensor):
        return  error_tensor.reshape(self.input_shape)

