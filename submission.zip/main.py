import pattern  # import pattern.py
import numpy as np
import matplotlib.pyplot as plt
import os
import json
import generator

resolution = 500
tile_size = 5
radius = 100
position = [300, 256]


if __name__ == '__main__':
    Checker = pattern.Checker(resolution, tile_size)  # 通过调用class Checker的constructor 构造函数创建实体Checker instance
    Checker.draw()
    Checker.show()
    Spectrum = pattern.Spectrum(resolution)
    Spectrum.draw()
    Spectrum.show()

    ######### Circle Part ##########
    Circle = pattern.Circle(resolution, radius, position)
    Circle.draw()
    Circle.show()
