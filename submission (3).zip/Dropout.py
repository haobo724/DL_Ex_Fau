from Layers.Base import BaseLayer
import numpy as np

class Dropout(BaseLayer):
    def __init__(self, probability):
        #set probability
        super().__init__()
        self.probability = probability
        self.filter = 0
        self._optimizer = None

    def forward(self, input_tensor):
        if  self.testing_phase:
            # for test phase no dropout
            return input_tensor
        else:#课件十三页
            #filtering the input with a filter to get rid of cells randomly
            filter = np.random.random(size=input_tensor.shape)
            #according to the probability set the filter
            filter[filter < 1-self.probability] = 0
            filter[filter >= 1-self.probability] = 1
            #set elements value after filtering as 1/p
            filter[filter == 1] = 1 / self.probability

            self.filter = filter
            output = filter * input_tensor
            return output

    def backward(self, error_tensor):
        #filtering backward as well
        #save time
        error_tensor = self.filter * error_tensor
        return error_tensor