import numpy as np
import math
import copy
from scipy.signal import convolve, correlate


class Conv:
    def __init__(self, stride_shape, convolution_shape, num_kernels):
        self.stride_shape = stride_shape
        self.convolution_shape = convolution_shape #kernels shape
        self.num_kernels = int(num_kernels)
        self.weights = np.random.uniform(0, 1, (num_kernels, *convolution_shape))
        self.bias = np.random.uniform(0, 1, num_kernels)
        self._gradient_weights = None
        self._gradient_bias = None
        self._optimizer = None

    def forward(self, input_tensor):
        self.input_tensor = input_tensor
        if (len(self.stride_shape) == 2):#stride for non-1D case
            stride_y, stride_x = self.stride_shape
            b, c, y, x = self.input_tensor.shape

            #output size smaller than input after stride
            output_tensor = np.zeros((b, self.num_kernels, y, x)) # the channel number of output is same as kernel number

            #correlate
            for i in range(b):
                for j in range(self.num_kernels):
                    cache = 0
                    for k in range(c):
                        #do correlate for each channel of each batch with each chanel of each kernel
                        cache += correlate(input_tensor[i][k], self.weights[j][k], 'same')
                    output_tensor[i][j] = cache + self.bias[j]

            if stride_y > 1 or stride_x > 1:
                output_tensor = output_tensor[:,:,::stride_y,::stride_x]
               
        else:
            #stride for 1D case, without x dimention
            stride_y = self.stride_shape[0]
            b, c, y = self.input_tensor.shape
            output_tensor = np.zeros((b, self.num_kernels, y))

            #same as non-1D case
            for i in range(b):
                for j in range(self.num_kernels):
                    cache = 0
                    for k in range(c):
                        cache += correlate(input_tensor[i][k], self.weights[j][k], 'same')
                    output_tensor[i][j] = cache + self.bias[j]
            # stride
            if (stride_y > 1):
                output_tensor = output_tensor[:, :, ::stride_y]

        return output_tensor

    @property
    def optimizer(self):
        return self._optimizer

    @optimizer.setter
    def optimizer(self, opt):
        self._optimizer = opt

    def backward(self, error_tensor):
        output_tensor = np.zeros_like(self.input_tensor)
        if len(self.stride_shape) == 2:
            stride_y, stride_x = self.stride_shape
            b, c, y, x = self.input_tensor.shape

            #reshape error_tensor for further convolve
            reshpe_error = np.zeros((b, self.num_kernels, y, x))
            _, _, E_y, E_x = error_tensor.shape
            reshpe_error[:,:,::stride_y,::stride_x] = error_tensor

        else:# for 1-D case
            stride_y = self.stride_shape[0]
            b, c, y = self.input_tensor.shape
            reshpe_error = np.zeros((b, self.num_kernels, y))
            reshpe_error[:,:,::stride_y] = error_tensor

        for i in range(b):
            for j in range(c):
                for k in range(self.num_kernels):
                    output_tensor[i][j] += convolve(reshpe_error[i][k], self.weights[k][j], 'same')

        stride_y = error_tensor.shape[0]
        stride_x = error_tensor.shape[1]
        # gradient bias
        self.gradient_bias = np.zeros(stride_x)
        for i in range(stride_y):
            for j in range(stride_x):
                self.gradient_bias[j] += np.sum(error_tensor[i][j])

        self.gradient_weights = np.zeros(np.shape(self.weights))
        # calculate gradient weights
        if (len(self.stride_shape) == 2):
            stride_x, _, y, x = self.weights.shape
            b, c, E_y, E_x = self.input_tensor.shape
            #reshape(padding) input size for further correlate with reshaped error
            padded_input = np.zeros((b, c, E_y + y - 1, E_x + x - 1))
            y = int(y / 2)
            x = int(x / 2)
            for i in range(b):
                for j in range(c):
                    padded_input[i, j, y:(E_y + y), x:(E_x + x)] = self.input_tensor[i][j]
        else:
            stride_x, _, y = self.weights.shape
            b, c, E_y = self.input_tensor.shape
            padded_input = np.zeros((b, c, E_y + y - 1))
            y = int(y / 2)
            for i in range(b):
                for j in range(c):
                    padded_input[i][j][y:(E_y + y)] = self.input_tensor[i][j]
        for i in range(stride_x):
            for j in range(b):
                for k in range(c):
                    self.gradient_weights[i][k] += correlate(padded_input[j][k], reshpe_error[j][i], mode='valid')

        # calculate weights and bias
        if (self._optimizer != None):
            weights_opt = copy.deepcopy(self.optimizer)
            bias_opt = copy.deepcopy(self.optimizer)
            self.weights = weights_opt.calculate_update(self.weights, self.gradient_weights)
            self.bias = bias_opt.calculate_update(self.bias, self.gradient_bias)

        return output_tensor
    #initialize
    def initialize(self, weights_initializer, bias_initializer):
        fan_in = int(np.size(self.weights) / self.weights.shape[0])
        fan_out = int(np.size(self.weights) / self.weights.shape[1])
        self.weights = weights_initializer.initialize(self.weights.shape, fan_in, fan_out)
        self.bias = bias_initializer.initialize(self.bias.shape, fan_in, fan_out)
