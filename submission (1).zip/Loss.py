import numpy as np

class CrossEntropyLoss:
    def __init__(self):
        pass

    def forward(self, input_tensor, label_tensor):
        #compute the loss of each batch and do sum in final. self.loss is the loss of current weights.
        self.y_head = np.zeros_like(label_tensor)
        self.loss = 0
        for i in range(input_tensor.shape[0]):
            self.y_head[i] = input_tensor[i] * label_tensor[i]
            self.loss += np.sum(-1 * np.log(np.sum(self.y_head[i]) + np.finfo(float).eps))
        return self.loss


    def backward(self, label_tensor):
        temp = self.y_head.copy()
        # set all 0 in denominator(y_head) as 1 so that calculations can be made. En = -1 * y / y_head
        temp[self.y_head == 0] = 1
        En = -1 * label_tensor / temp
        return En
