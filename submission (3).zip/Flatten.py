from Layers.Base import BaseLayer
import numpy as np

class Flatten(BaseLayer):
    def __init__(self):
        super().__init__()
        self._optimizer = None

        self.input_shape = None

    def forward(self, input_tensor):
        '''''
        self.input_shape = input_tensor.shape
        total = input_tensor.shape[1] * input_tensor.shape[2] * input_tensor.shape[3]
        output = np.ones([input_tensor.shape[0],total])
        for i in range (input_tensor.shape[0]):
            output[i]=input_tensor[i].flatten()
        return  output
        '''

        # the first dimention of input_tensor repersent batch numbers.
        # we create a empty matrix which takes batch number as row and element number as column to store the reshaped input_tensor
        self.input_shape = np.shape(input_tensor) #store for backward
        x = int(self.input_shape[0])
        #a, b, c, d = self.input_shape
        #y = int(b * c * d)
        y = int(np.prod(self.input_shape[1:]))

        #reshape input size
        output = input_tensor.reshape(x,y)
        return output

    def backward(self, error_tensor):

        return error_tensor.reshape(self.input_shape)
