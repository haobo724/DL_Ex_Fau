import numpy as np
from Layers.Base import BaseLayer

class ReLU(BaseLayer):#加了继承
    def __init__(self):
        self._optimizer = None
        super().__init__()

    def forward(self, input_tensor):
        self.output = np.maximum(0, input_tensor)
        return self.output

    def backward(self, error_tensor):
        if_greater_than_0 = np.zeros_like(error_tensor)
        if_greater_than_0[self.output > 0] = 1
        return error_tensor * if_greater_than_0