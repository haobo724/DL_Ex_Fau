import numpy as np
class Sigmoid:
    def __init__(self):
        pass
    def forward(self, input_tensor):
        input_tensor = 1 / (1 + np.exp(-input_tensor))
        self.sigmoid_deri = input_tensor * (1 - input_tensor)
        return input_tensor

    def backward(self, error_tensor):
        error_tensor = self.sigmoid_deri * error_tensor
        return error_tensor
