import numpy as np
from Layers.FullyConnected import FullyConnected
from Layers.TanH import TanH
from Layers.Sigmoid import Sigmoid
import copy

class RNN:
    def __init__(self,input_size, hidden_size, output_size):
        self._memorize = False
        self.input_size  = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.FC_in_size = self.input_size + self.hidden_size
        self.FC_out_size = self.hidden_size
        self.FC_framework = FullyConnected(self.FC_in_size, self.hidden_size)
        self.FC_hidden_frame = FullyConnected(self.hidden_size, self.output_size)
        self.Hidden_state = np.zeros([1, self.hidden_size])
        self._optimizer = None

    @property
    def memorize(self):
        return self._memorize
    @memorize.setter
    def memorize(self, value):
        self._memorize = value
    @property
    def weights(self):
        return self.FC_framework.weights
    @weights.setter
    def weights(self,xx):
        self.FC_framework.weights = xx
    @property
    def gradient_weights(self):
        return  self.FC_framework.gradient_weights
    @gradient_weights.setter
    def gradient_weights(self,xx):
        self.FC_framework.gradient_weights = xx
    @property
    def optimizer(self):
        return self._optimizer
    @optimizer.setter
    def optimizer(self, value):
        self._optimizer = copy.deepcopy(value)
        self.FC_framework.optimizer = copy.deepcopy(value)
        self.FC_hidden_frame.optimizer = copy.deepcopy(value)


    def forward(self, input_tensor):
        batch_num = input_tensor.shape[0]
        tanh_ori = TanH()
        sigmoid_ori = Sigmoid()
        self.listeForTanh = []
        self.listForSigmoid = []
        self.listForFC1 = []
        self.listForFC2 = []
        output = np.zeros([batch_num, self.output_size])

        if not self._memorize:
            self.Hidden_state = np.zeros((1, self.hidden_size))

        for i in range(batch_num):
            tanh = copy.deepcopy(tanh_ori)
            sigmoid = copy.deepcopy(sigmoid_ori)
            fc_framwork = copy.deepcopy(self.FC_framework)
            fc_hiddenframe = copy.deepcopy(self.FC_hidden_frame)
            temp = np.zeros([1, self.FC_in_size])
            temp[0,0: self.input_size] = input_tensor[i]
            temp[0,self.input_size:] = self.Hidden_state
            hidden = fc_framwork.forward(temp).reshape(1, self.hidden_size)
            self.Hidden_state = tanh.forward(hidden)
            self.listeForTanh.append(tanh)
            output_of_hidden = fc_hiddenframe.forward(self.Hidden_state)
            self.listForFC1.append(fc_framwork)
            self.listForFC2.append(fc_hiddenframe)
            output[i] = sigmoid.forward(output_of_hidden[0])
            self.listForSigmoid.append(sigmoid)
        return output

    def backward(self, error_tensor):
        batch_num = error_tensor.shape[0]
        error = np.zeros([batch_num, self.input_size])
        hidden_state = np.zeros([1, self.hidden_size])
        gradient_weight_FC1 = 0
        gradient_weight_FC2 = 0
        for i in np.flipud(range(batch_num)):
            sigmoid_deri = self.listForSigmoid[i]
            temp= sigmoid_deri.backward(error_tensor[i])
            temp = temp.reshape((1, temp.shape[0]))
            temp = self.listForFC2[i].backward(temp)
            temp += hidden_state
            temp = self.listeForTanh[i].backward(temp)
            temp = self.listForFC1[i].backward(temp)
            error[i] = temp[0, 0 : self.input_size]
            hidden_state = temp[0,self.input_size:]

            gradient_weight_FC1 += self.listForFC1[i].gradient_weights
            gradient_weight_FC2 += self.listForFC2[i].gradient_weights

        self.FC_framework.gradient_weights = gradient_weight_FC1
        self.FC_hidden_frame.gradient_weights = gradient_weight_FC2

        if self.optimizer is not None:
            self.FC_framework.weights = self.optimizer.calculate_update(self.FC_framework.weights,gradient_weight_FC1)
            self.FC_hidden_frame.weights = self.optimizer.calculate_update(self.FC_hidden_frame.weights,gradient_weight_FC2)
            #self.FC_framework.gradient_weights = gradient_weight_FC1
            #self.FC_hidden_frame.gradient_weights = gradient_weight_FC2
        return error

    def initialize(self, weights_initializer, bias_initializer):
        #as in slide, for fully connected layers fan_in = fan_out = dimension of weights and it is a intger(mutiply all dimention of weights).
        self.FC_framework.initialize(weights_initializer,bias_initializer)
        self.FC_hidden_frame.initialize(weights_initializer,bias_initializer)
