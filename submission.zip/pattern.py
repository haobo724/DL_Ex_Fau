import numpy as np
import matplotlib.pyplot as plt
import math


class Checker:  # 画一个黑白相间的棋盘，棋盘由很多数组拼接而成，
    # 棋盘上每个格子（tile）都是一个数组，纯黑1或者纯白0，
    # 分辨率resolution是有几个pixel，tile是每个小格有具体有几个pixel
    # 棋盘还要是偶数，所以最小单元棋盘为2*2（tile）的黑白相间的棋盘

    def __init__(self, resolution, tile_size):
        self.resolution = resolution  # py中全局变量的设置
        self.tile_size = tile_size
        self.output = np.zeros((self.resolution, self.resolution))

    def draw(self):
        even = self.resolution % (2 * self.tile_size)
        if even == 0:
            tile_number = math.floor(self.resolution / (2 * self.tile_size))  # tile_nummer要保证是个整形，傻逼python
            # tile_number = self.resolution / (2 * self.tile_size)
            print(tile_number)
            tile_white = np.ones([self.tile_size, self.tile_size])
            tile_black = np.zeros([self.tile_size, self.tile_size])
            tile_on_y_1 = np.vstack((tile_black, tile_white))
            tile_on_y_2 = np.vstack((tile_white, tile_black))
            tile = np.hstack((tile_on_y_1, tile_on_y_2))
            self.output = np.tile(tile, [tile_number, tile_number])
        else:
            print("resolution is not correct")
        return np.copy(self.output)

    def show(self):
        plt.imshow(self.output,cmap='gray')
        plt.show()


class Circle:
    # 画一个圆在图中，position是圆心,1是白色，0是黑色(啥也没有)

    def __init__(self, resolution, radius, position):
        self.resolution = resolution  # py中全局变量的设置
        self.radius = radius
        self.position = position
        self.output = np.zeros((self.resolution, self.resolution))

    def draw(self):
        x = self.position[0]
        y = self.position[1]
        
        # edge_y, edge_x = np.ogrid[-self.radius: self.radius, -self.radius: self.radius]
        # index = edge_x ** 2 + edge_y ** 2 <= self.radius ** 2
        # self.output[y - self.radius:y + self.radius, x - self.radius:x + self.radius][index] = 1

        circley = np.arange(self.resolution).reshape(self.resolution, 1)
        circlex = np.arange(self.resolution).reshape(1, self.resolution)
        dis = np.sqrt((circlex-x)**2+(circley-y)**2) #dis 中每个单元格里的值是到圆心的距离
        self.output = dis <= self.radius * 1
        return np.copy(self.output)

    def show(self):
        plt.imshow(self.output, cmap='binary')
        plt.show()


class Spectrum:
    # R是从左到右0-1 B是从左到右1-0 G是从上到下0-1

    def __init__(self, resolution):
        self.resolution = resolution  # py中全局变量的设置
        self.output = np.zeros((self.resolution, self.resolution, 3))

    def draw(self):
        R = np.linspace(0.0, 1.0, self.resolution)
        B = np.linspace(1.0, 0.0, self.resolution)
        G = R.reshape(self.resolution, 1)
        R = np.tile(R, [self.resolution, 1])
        B = np.tile(B, [self.resolution, 1])
        G = np.tile(G, [1, self.resolution])
        self.output[:, :, 0] = R
        self.output[:, :, 1] = G
        self.output[:, :, 2] = B
        return np.copy(self.output)

    def show(self):
        plt.imshow(self.output)
        plt.show()
