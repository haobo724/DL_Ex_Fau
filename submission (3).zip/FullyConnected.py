import numpy as np
from Layers.Base import BaseLayer



#多了继承
class FullyConnected(BaseLayer):
    def __init__(self, input_size, output_size):
        super().__init__()
        # weight is a matrix with row of inputsize and col of outputsize
        # bias default as 1
        # weights: the combination of weight matrix and bias
        self.bias = np.ones(output_size)
        self.weight = np.random.uniform(0, 1, size=[input_size, output_size])
        self._optimizer = None
        self._gradient_weights = None
        self._weights = None
        self.weights = np.vstack((self.weight, self.bias))

    def forward(self, input_tensor):
        self.inputtensor = input_tensor
        # extend the input matrix with an extra column, which represent the bias
        self.X = np.column_stack((input_tensor,np.ones(input_tensor.shape[0])))
        self.output = np.dot(self.X, self.weights)
        return self.output


    #
    @property
    def weights(self):
        return self._weights
    @weights.setter
    def weights(self, a):
        self._weights = a

    @property
    def gradient_weights(self):
        return self._gradient_weights
    @gradient_weights.setter
    def gradient_weights(self, b):
        self._gradient_weights = b

    def backward(self, error_tensor):
        updated_error = np.dot(error_tensor, self.weight.T)
        self._gradient_weights = np.dot(self.X.T, error_tensor)
        if (self.optimizer is not None):
            self.weights = self.optimizer.calculate_update(self.weights, self.gradient_weights)
        return  updated_error

    def initialize(self, weights_initializer, bias_initializer):
        fan_in = np.prod(np.shape(self.weight))
        fan_out = fan_in
        self.bias = bias_initializer.initialize(np.shape(self.bias), fan_in, fan_out)
        self.weight = weights_initializer.initialize(np.shape(self.weight), fan_in, fan_out)
        self.weights = np.vstack((self.weight,self.bias))
