
import copy

class NeuralNetwork:# connect all of layer together

    @property
    def phase(self):
        return self._phase

    @phase.setter
    def phase(self, value):
        self._phase = value

    def __init__(self,optimizer,weights_initializers,bias_initializers):
        self.optimizer = optimizer
        self.weights_initializers = weights_initializers
        self.bias_initializers = bias_initializers
        ####################################
        self._phase = None
        self.loss = []
        self.layers = []
        self.data_layer = None
        self.loss_layer = None



    def forward(self):#通过调用data_layer的forword function 得到input和label
        self.input_tensor, self.label_tensor = self.data_layer.forward()

        input = self.input_tensor
        label = self.label_tensor

        loss = 0

        for layer in self.layers:#获取下一个layer的input
            input = layer.forward(input)
            # plus regulation loss!
            loss += layer.calculate_regularization_loss()
            #sum up
        loss += self.loss_layer.forward(input,label)
        return loss #下面train会用到

    def backward(self):
        # 返回一个error大小
        error_tensor = self.loss_layer.backward(self.label_tensor)
        for layer in reversed(self.layers):
            error_tensor = layer.backward(error_tensor)
        return error_tensor

    def append_trainable_layer(self,layer):#set optimizer for each layer
        op = copy.deepcopy(self.optimizer)
        layer.optimizer = op
        #这块不知道有没有更好的写法

        layer.initialize(self.weights_initializers, self.bias_initializers)

        self.layers.append(layer)




    def train(self,iterations):
        for layer in self.layers:
            layer.testing_phase = False
        for i in range(iterations):
            self.loss.append(self.forward()) # store loss in loss list
            self.backward()

    def test(self,input_tensor):
        input_tensor4test = input_tensor
        for layer in self.layers:# each layer
            layer.testing_phase = True
            input_tensor4test = layer.forward(input_tensor4test)#update
        return input_tensor4test# not a input now rather a prediction


