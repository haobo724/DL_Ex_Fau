import numpy as np


class Pooling:
    def __init__(self, stride_shape, pooling_shape):
        self.stride_shape = stride_shape
        self.pooling_shape = pooling_shape

    def forward(self,input_tensor):
        stride_shape_w,stride_shape_h = self.stride_shape
        p, q = self.pooling_shape


        if len(input_tensor.shape)==3:
            input_tensor = np.expand_dims(input_tensor,axis=3)

        self.input_tensor = input_tensor
        b, c, y, x = input_tensor.shape
        self.B=b
        self.C=c
        size_y = int(np.floor(y / stride_shape_w))
        self.size_Y = size_y
        size_x = int(np.floor(x / stride_shape_h))
        if stride_shape_w == 1:
            size_y = y - (p - 1)
        if stride_shape_h == 1:
            size_x = x - (q - 1)

        output_tensor = np.zeros((b,c,size_y,size_x))
        self.indexofinput=[]

        for m in range(b):
            for n in range(c):
               for i in range(size_y):
                   for j in range(size_x):
                      maxium = np.max(input_tensor[m, n, i*stride_shape_w:i *stride_shape_w+p,  j * stride_shape_h:j * stride_shape_h + q])
                      index = np.where(input_tensor[m, n, i*stride_shape_w:i *stride_shape_w+p,  j * stride_shape_h:j * stride_shape_h + q]==maxium)
                      output_tensor[m,n,i,j] =maxium
                      self.indexofinput.append((m, n, index[0] + stride_shape_w * i, index[1] + stride_shape_h * j))

        if len(output_tensor.shape) == 3:
            output_tensor = np.reshape(output_tensor,(b,c,size_y))

        return output_tensor

    def backward(self, error_tensor):
        if len(error_tensor.shape) == 3:
            error_tensor = np.expand_dims(error_tensor, axis=3)

        output_tensor = np.zeros_like(self.input_tensor)
        temp= error_tensor.flatten()

        for m, i in zip(self.indexofinput, temp):
            output_tensor[m] += i
        if len(output_tensor.shape) == 3:
            output_tensor = np.reshape(output_tensor, (self.B, self.C, self.size_Y))
        return output_tensor