import numpy as np

class L2_Regularizer:
    def __init__(self, alpha):
        self.alpha = alpha
        self.loss = 0

    def calculate_gradient(self, weights):
        #regularzation slide page 3, the whole formular will be repersented with optimazier class (backwards)
        gradient = self.alpha * weights
        return gradient

    def norm(self, weights):
        self.loss += self.loss + self.alpha * np.linalg.norm(weights)
        loss = self.loss
        return loss

class L1_Regularizer:
    def __init__(self, alpha):
        self.alpha = alpha
        self.loss = 0

    def calculate_gradient(self, weights):
        #regularzation slide page 4, the whole formular will be repersented with optimazier class (backwards)
        gradient = np.sign(weights) * self.alpha
        return gradient

    def norm(self, weights):
        self.loss += self.alpha * np.sum(np.abs(weights))
        loss = self.loss
        return loss