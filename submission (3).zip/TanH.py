import numpy as np
class TanH:
    def __init__(self):
        pass
    def forward(self, input_tensor):
        input_tensor = np.tanh(input_tensor)
        self.tanh_deri = 1 - np.power(input_tensor, 2)
        return input_tensor

    def backward(self, error_tensor):
        error_tensor = self.tanh_deri * error_tensor
        return error_tensor


