import torch.nn.modules

class ResBlock(torch.nn.modules.Module):
    def __init__(self, inputchannal, outputchannel, stride):
        super().__init__()
        self.conv2d = torch.nn.modules.Conv2d(inputchannal, outputchannel, 1, stride)
        self.batch = torch.nn.modules.BatchNorm2d(outputchannel)
        self.relu = torch.nn.modules.ReLU()

        self.conv2d_2nd = torch.nn.modules.Conv2d(inputchannal, outputchannel, 3, stride,padding=1)
        self.batch_2nd = torch.nn.modules.BatchNorm2d(outputchannel)

        self.conv2d_3rd = torch.nn.modules.Conv2d(outputchannel, outputchannel, 3,padding=1)
        self.batch_3rd = torch.nn.modules.BatchNorm2d(outputchannel)

    def forward(self,input):
        input_main = self.relu(self.batch(self.conv2d(input)))
        input_side = self.relu(self.batch_2nd(self.conv2d_2nd(input)))
        input_side = self.relu(self.batch_3rd(self.conv2d_3rd(input_side)))

        return input_main + input_side

class ResNet(torch.nn.modules.Module):
     def __init__(self):
        super().__init__()


        self.conv2d = torch.nn.modules.Conv2d(3,64,7,2)
        self.batch =  torch.nn.modules.BatchNorm2d(64)
        self.relu = torch.nn.modules.ReLU()
        self.maxpool = torch.nn.modules.MaxPool2d(3,2)
        self.resblock1 = ResBlock(64,64,1)
        self.resblock2 = ResBlock(64,128,2)
        self.resblock3 = ResBlock(128,256,2)
        self.resblock4 = ResBlock(256,512,2)
        self.globalavpool = torch.nn.modules.AdaptiveAvgPool2d(1)
        self.flatten = torch.nn.modules.flatten.Flatten()
        self.fc = torch.nn.modules.linear.Linear(512,2)
        self.sigmod = torch.nn.modules.Sigmoid()

     def forward(self,input):
         input = self.maxpool(self.relu(self.batch(self.conv2d(input))))
         input = self.resblock4(self.resblock3(self.resblock2(self.resblock1(input))))



         output = self.sigmod(self.fc(self.flatten(self.globalavpool(input))))
         return output

