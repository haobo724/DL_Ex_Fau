import numpy as np

class FullyConnected:
    def __init__(self, input_size, output_size):
        # weight is a matrix with row of inputsize and col of outputsize
        # bias default as 1
        # weights: the combination of weight matrix and bias
        self.bias = np.ones(output_size)
        self.weight = np.random.uniform(0, 1, size=[input_size, output_size])
        self._optimizer = None
        self.weights = np.vstack((self.weight, self.bias))

    def forward(self, input_tensor):
        self.inputtensor = input_tensor
        # extend the input matrix with an extra column, which represent the bias
        self.X= np.hstack((input_tensor, np.ones((input_tensor.shape[0],1))))
        self.output = np.dot(self.X, self.weights)
        return self.output

    @property
    def optimizer(self):
        return self._optimizer

    @optimizer.setter
    def optimizer(self, value):
        self._optimizer = value

    def backward(self, error_tensor):
        updated_error = np.dot(error_tensor, self.weight.T)
        self.gradient_weights = np.dot(self.X.T, error_tensor)
        if (self.optimizer is not None):
            self.weights = self.optimizer.calculate_update(self.weights, self.gradient_weights)
        return  updated_error
