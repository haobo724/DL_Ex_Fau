from Layers.Base import BaseLayer
import numpy as np
import copy
from scipy.signal import convolve, correlate



# 加了继承
class Conv(BaseLayer):
    def __init__(self, stride_shape, convolution_shape, num_kernels):
        super().__init__()
        ##########################properties#############################
        self._gradient_bias = None
        self._gradient_weights = None
        self._optimizer = None
        ##########################variant################################
        self.weights = np.random.random((num_kernels, *convolution_shape))
        self.bias = np.random.random(num_kernels)
        self.stride_shape = stride_shape
        self.num_kernels = int(num_kernels)
        self.convolution_shape = convolution_shape  # kernels shape

    def initialize(self, weights_initializer, bias_initializer):
        self.weightsize = np.size(self.weights)
        in_value = self.weights.shape[0]
        out_value = self.weights.shape[1]
        fan_in = int(self.weightsize/in_value)
        fan_out = int(self.weightsize/out_value)
        self.weights = weights_initializer.initialize(self.weights.shape, fan_in, fan_out)
        self.bias = bias_initializer.initialize(self.bias.shape, fan_in, fan_out)
    ######################################################################
    @property
    def optimizer(self):
        return self._optimizer
    @optimizer.setter
    def optimizer(self, QAQ):
        self._optimizer = QAQ

    @property
    def gradient_weights(self):
        return self._gradient_weights
    @gradient_weights.setter
    def gradient_weights(self, oo):
        self._gradient_weights = oo

    @property
    def gradient_bias(self):
        return self._gradient_bias
    @gradient_bias.setter
    def gradient_bias(self, xx):
        self._gradient_bias = xx

    def forward(self, input_tensor):

        #s = self.stride_shape
        #w = self.weights
        #b = self.bias
        self.input_tensor = input_tensor
        # stride for non-1D case
        if (len(self.stride_shape) == 1):
            # stride for 1D case w.r.t without x dimention
            stride_y = self.stride_shape[0]#
            #inputtensor is 3D (without x)
            b, c, y = self.input_tensor.shape
            forward_out = np.zeros((b, self.num_kernels, y))
            # same as non-1D case
            for i in range(b):
                for j in range(self.num_kernels):
                    cache = 0
                    for k in range(c):
                        cache += correlate(input_tensor[i][k], self.weights[j][k], 'same')
                    forward_out[i][j] = cache + self.bias[j]
            forward_out = forward_out[:, :, ::stride_y]
        else:
            b, c, y, x = self.input_tensor.shape
            # stride also means step
            stride_y, stride_x = self.stride_shape
            # output size smaller than input after stride
            # the channel number of output is same as kernel number
            forward_out = np.zeros((b, self.num_kernels, y, x))
            for i in range(b):
                # for every batch
                for j in range(self.num_kernels):
                    # for every kernel
                    cache = 0
                    for k in range(c):
                        # do correlate for each channel of each batch with each chanel of each kernel
                        cache += correlate(input_tensor[i][k], self.weights[j][k], 'same')
                        # for i in range(n):
                        #    self.bias[i] *= bias[i]
                        # forward_out = forward_out.correlate(input_tensor[j], self.weights[i], mode='same')
                    forward_out[i][j] = cache + self.bias[j]

            forward_out = forward_out[:, :, ::stride_y, ::stride_x]
        return forward_out

    def backward(self, error_tensor):
        #output pattern
        backward_out = np.zeros((self.input_tensor.shape))
        ####################option 1##################################
        if len(self.convolution_shape) == 3:
            stride_y, stride_x = self.stride_shape
            b, c, y, x = self.input_tensor.shape

            # reshape error_tensor for further convolve
            reshpe_error = np.zeros((b, self.num_kernels, y, x))
            _, _, E_y, E_x = error_tensor.shape
            reshpe_error[:, :, ::stride_y, ::stride_x] = error_tensor

        else:  # for 1-D case
            stride_y = self.stride_shape[0]
            b, c, y = self.input_tensor.shape
            reshpe_error = np.zeros((b, self.num_kernels, y))
            reshpe_error[:, :, ::stride_y] = error_tensor

        for i in range(b):
            for j in range(c):
                for k in range(self.num_kernels):
                    backward_out[i][j] += convolve(reshpe_error[i][k], self.weights[k][j], 'same')

        stride_y = error_tensor.shape[0]
        stride_x = error_tensor.shape[1]
        self.gradient_bias = np.zeros(stride_x)
        for i in range(stride_y):
            for j in range(stride_x):
                self.gradient_bias[j] += np.sum(error_tensor[i][j])

        self.gradient_weights = np.zeros(np.shape(self.weights))
        ###################################################################

        #############################option 2####################################

        if (len(self.stride_shape) == 2):
            stride_x, _, y, x = self.weights.shape
            b, c, E_y, E_x = self.input_tensor.shape
            # reshape(padding) input size for further correlate with reshaped error

            padded_input = np.zeros((b, c, E_y + y - 1, E_x + x - 1))
            y = int(y / 2)
            x = int(x / 2)
            #[b, c, y] = np.shape(input_tensor)
            for i in range(b):
                for j in range(c):
                    padded_input[i, j, y:(E_y + y), x:(E_x + x)] = self.input_tensor[i][j]
        else:
            stride_x, _, y = self.weights.shape
            b, c, E_y = self.input_tensor.shape
            #[b,c,y,x] = np.shape(input_tensor)
            padded_input = np.zeros((b, c, E_y + y - 1))
            #y2 = int(np.ceil(y/step[0]))
            #x2 = int(np.ceil(x/step[1]))

            y = int(y / 2)
            for i in range(b):
                for j in range(c):
                    padded_input[i][j][y:(E_y + y)] = self.input_tensor[i][j]
        for i in range(stride_x):
            for j in range(b):
                for k in range(c):
                    self.gradient_weights[i][k] += correlate(padded_input[j][k], reshpe_error[j][i], mode='valid')
        #############################################################

        #################### optimizer ##############################
        if (self._optimizer is not None):
            optimizer1 = copy.copy(self.optimizer)
            self.weights = optimizer1.calculate_update(self.weights, self.gradient_weights)

            optimizer2 = copy.copy(self.optimizer)
            self.bias = optimizer2.calculate_update(self.bias, self.gradient_bias)
        #############################################################
        return backward_out


