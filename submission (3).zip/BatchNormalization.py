from Layers.Helpers import compute_bn_gradients
import numpy as np
from Layers.Base import BaseLayer
import copy

class BatchNormalization(BaseLayer):
    def __init__(self, channels):
        super().__init__()
        self.channels = channels
        self.weights=None
        self.bias=None
        self.initialize(self.channels ,self.channels )

        self._gradient_weights = None
        self._gradient_bias = None

        # for gradient update
        self._optimizer = None
        self.weights_optimizer = None
        self.bias_optimizer = None

        self.batch_mean = None
        self.batch_var = None

        # mean and variance estimation in moving average method
        self.alpha = 0.8  # 课件/3_1_Regularization.pdf 26页
        self.estimate_mean = None
        self.estimate_var = None

        self.flag = None#标记进来的是bild还是vetor
        self.input_tensor = None

        self.input_shape = None
        self.epsilon = 1e-18 #要比1e-10小


        self.input_hat = None# input_tensor_hat

    def initialize(self,channels,channels2):
        self.weights = np.ones((1, self.channels))
        self.bias = np.zeros((1, self.channels))

    def forward(self, input_tensor):

        self.input_shape = input_tensor.shape
        if input_tensor.ndim == 4: # if import is a CNN Bild ,which means it has 4 Dims then flatten it in to 2 dims
            self.flag = 'bild'
            self.input_tensor=self.reformat(input_tensor)

        else:
         self.flag = 'vec'
         self.input_tensor = input_tensor


        if self.testing_phase == True:
            self.batch_mean = self.estimate_mean
            self.batch_var = self.estimate_var


        else:# train phase
            self.batch_mean = np.mean(self.input_tensor, axis=0).reshape(1, -1)
            self.batch_var = np.var(self.input_tensor, axis=0).reshape(1, -1)
            #每个channal一个mean和var

            if self.estimate_mean is None:
                self.estimate_mean = self.batch_mean
            if self.estimate_var is None:
                self.estimate_var = self.batch_var
            # 课件/3_1_Regularization.pdf 26页
            self.estimate_var = self.alpha * self.estimate_var + (1 - self.alpha) * self.batch_var
            self.estimate_mean = self.alpha * self.estimate_mean + (1 - self.alpha) * self.batch_mean
        # 课件/3_1_Regularization.pdf 22页
        self.input_hat = (self.input_tensor - self.batch_mean) / np.sqrt(self.batch_var + self.epsilon)

        # 课件/3_1_Regularization.pdf 22页
        output_tensor = self.weights * self.input_hat + self.bias

        if self.flag == 'bild':#2-->4
            output_tensor = self.reformat(output_tensor)
        return output_tensor

    def reformat(self, tensor):  # 4-->2,2--->4
        if self.input_shape is None:
            B = tensor.shape[0]
            H = tensor.shape[1]
            M = tensor.shape[2]
            N = tensor.shape[3]
        else:
            B = self.input_shape[0]
            H = self.input_shape[1]
            M = self.input_shape[2]
            N = self.input_shape[3]

        if tensor.ndim == 4:

            tensor = tensor.reshape(B, H, M * N)  # (B, H, M, N) -> (B, H, M * N)
            tensor = np.transpose(tensor, (0, 2, 1))  # (B, H, M * N)->(B, M * N, H)  M*N = line
            tensor = tensor.reshape(B * M * N, H)  # (B, line, H) -> (B * line, H) ,二维
            #self.flag = 'bild'

        else:  # 2--->4 ,backwards
            tensor = tensor.reshape(B, M * N, H)  # (B * M * N, H) -> (B, M * N, H)
            tensor = np.transpose(tensor, (0, 2, 1))  # (B, M * N, H) -> (B, H, M * N)
            tensor = tensor.reshape((B, H, M, N))  # (B, H, M * N) -> (B, H, M, N)
        return tensor

    def backward(self, error_tensor):
        if error_tensor.ndim == 4:#同理4->2
            error_tensor = self.reformat(error_tensor)
        # 课件/3_1_Regularization.pdf 27页
        self._gradient_weights = np.sum(error_tensor * self.input_hat, axis=0).reshape(1, -1)
        self._gradient_bias = np.sum(error_tensor, axis=0).reshape(1, -1)

        #没有就初始化一个
        if self.weights_optimizer is not None:
            self.weights = self.weights_optimizer.calculate_update(self.weights, self._gradient_weights)
        if self.bias_optimizer is not None:
            self.bias = self.bias_optimizer.calculate_update(self.bias, self._gradient_bias)


        input_gradient = compute_bn_gradients(error_tensor, self.input_tensor, self.weights, self.batch_mean,
                                              self.batch_var)
        if self.flag == 'bild':#2->4
            input_gradient = self.reformat(input_gradient)

        return input_gradient