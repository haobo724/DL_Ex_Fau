import numpy as np
from Layers.Base import BaseLayer

# add Baselayer for ex3
class SoftMax(BaseLayer):
    def __init__(self,):
        self._optimizer = None
        super().__init__()

    def forward(self,input_tensor):
      self.Y = np.zeros_like(input_tensor)
      # traverse every single batch to compute the maximum of x
      # every sigle element of input has its own prediction Y. self.Y is a matrix which has the same shape as input matrix represending the perdiction result.
      for i in range (input_tensor.shape[0]):
          max_x = np.max(input_tensor[i])
          exp_Xk = np.exp(input_tensor[i] - max_x)
          self.Y[i] = exp_Xk / np.sum(exp_Xk)
      return self.Y

    def backward(self,error_tensor):
        #compute the error_tensor for the 'last' layer base on the formula
        self.En_1 = np.zeros_like(error_tensor)
        for i in range(error_tensor.shape[0]):
            sum_en = np.sum(error_tensor[i] * self.Y[i])
            self.En_1[i] = self.Y[i] * (error_tensor[i] - sum_en)
        return self.En_1