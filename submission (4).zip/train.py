import torch as t
from data import ChallengeDataset
from trainer import Trainer
from matplotlib import pyplot as plt
import numpy as np
import model
import pandas as pd
from sklearn.model_selection import train_test_split
import torch.utils.data

learning_rate = 0.0000005
# load the data from the csv file and perform a train-test-split
# this can be accomplished using the already imported pandas and sklearn.model_selection modules
# TODO
data =pd.read_csv('data.csv', sep=';')
trainset , valset = train_test_split(data,test_size=0.001, shuffle=True)





# set up data loading for the training and validation set each using t.utils.data.DataLoader and ChallengeDataset objects
# TODO
train_dl = t.utils.data.DataLoader(ChallengeDataset(trainset,'train'), batch_size=15,shuffle=True,pin_memory=True)
val_dl = t.utils.data.DataLoader(ChallengeDataset(valset, 'val'), batch_size=15,shuffle=True,pin_memory=True)

# create an instance of our ResNet model
resss= model.ResNet()
# TODO

# set up a suitable loss criterion (you can find a pre-implemented loss functions in t.nn)
# crit = t.nn.modules.BCEWithLogitsLoss()
crit = t.nn.modules.BCELoss()
# set up the optimizer (see t.optim)
opt = t.optim.Adam(resss.parameters(),learning_rate)
# create an object of type Trainer and set its early stopping criterion
trainer2 = Trainer(resss, crit, opt, train_dl, val_dl, cuda=True, early_stopping_patience=10)
print(trainer2)
# TODO

# go, go, go... call fit on trainer
res = trainer2.fit(100)#TODO

# plot the results
plt.plot(np.arange(len(res[0])), res[0], label='train loss')
plt.plot(np.arange(len(res[1])), res[1], label='val loss')
plt.yscale('log')
plt.legend()
plt.savefig('losses.png')