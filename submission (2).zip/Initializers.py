import numpy as np

class UniformRandom:
    def __init__(self):
        pass

    def initialize(self, weights_shape, fan_in, fan_out):
        output = np.random.uniform(size=weights_shape)
        return output

class Constant:
    def __init__(self, value=0.1):
            self.value = value

    def initialize(self, weights_shape, fan_in, fan_out):
            output = np.ones(weights_shape) * self.value
            return output

class Xavier:
    def __init__(self):
        pass

    def initialize(self, weights_shape, fan_in, fan_out):
        sigma = np.sqrt(2 / (fan_out + fan_in)) #as in slide
        mu = 0
        gaussian = np.random.randn(*weights_shape)
        output = sigma * gaussian + mu
        return output

class He:
    def __init__(self):
        pass

    def initialize(self, weights_shape, fan_in, fan_out):
        sigma = np.sqrt(2 / fan_in) #as in slide
        mu = 0
        gaussian = np.random.randn(*weights_shape)
        output = sigma * gaussian + mu
        return output
