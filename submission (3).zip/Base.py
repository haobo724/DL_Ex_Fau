import copy

class BaseLayer:
    #All layers need to inherit from this "base-layer" so refactor them accordingly.
    def __init__(self):
        self.testing_phase = False
        self.weights = None #???

    def calculate_regularization_loss(self):
        #this is for Neuralnetwork forward part.
        if self.optimizer is not None and self.optimizer.regularizer is not None:
            #caculate regularization and sum it up
            return self.optimizer.regularizer.norm(self.weights)
        # if no require for regularization then output normal loss
        return 0

    @property
    def optimizer(self):
        return self._optimizer

    @optimizer.setter
    def optimizer(self, opt):
        self._optimizer = opt
        self.weights_optimizer = copy.deepcopy(self._optimizer)
        self.bias_optimizer = copy.deepcopy(self._optimizer)

    @property
    def gradient_weights(self):
        return self._gradient_weights



    @gradient_weights.setter
    def gradient_weights(self, gradient_weights):
        self._gradient_weights = gradient_weights


    @property
    def gradient_bias(self):
        return self._gradient_bias


    @gradient_bias.setter
    def gradient_bias(self, gradient_bias):
        self._gradient_bias = gradient_bias


